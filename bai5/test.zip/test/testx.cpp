#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <cstring>
using namespace std;

 
void rand_text(int length, char *result) {
    int i, rand_int;
    char char_set[] = "01234 56789 ABCDEF GHIJKL MNOPQRST UVWXYZ abcdef ghijklm nopqrstu vwxyz & quot ";
 
    for (i = 0; i <length; i++) {
        result[i] = char_set[rand() % sizeof(char_set)];
    }
    result[length] = 0;
}
 
void replowcase(char *str)
{
	int length = strlen(str);
	int i;
	bool isSpace = false;
	for (i = 0; i < length; i++)
	{
		// the first character of string
		if (i == 0 && str[i] != ' ' && str[i] != '\t')
		{
			if (str[i] <= 'z' && str[i] >= 'a')
			{
				str[i] = str[i] - 32;
			}
		}
		if (str[i] == ' ' || str[i] == '\t')
		{
			isSpace = true;
		}
		else if (isSpace)
		{
			if (str[i] <= 'z' && str[i] >= 'a')
			{
			str[i] = str[i] - 32;
			}
			isSpace = false;
		}
	}
}


void generateTest(int testNumber, char *a, char *b) {
  string inputFilename =  to_string(testNumber) + ".in";
  ofstream inputFile(inputFilename);

  inputFile<<a<<endl;

  
//  int output1 = giatrimax(a,n); int output2 = giatrimin(a,n);


  string outputFilename = to_string(testNumber) + ".out";
  ofstream outputFile(outputFilename);
	outputFile<<b;
  
  inputFile.close();
  outputFile.close();
}

int main() {
	int n;
	srand(time(NULL)); 
	
  int numTests = 10; 
  int minInput = -30000; 
  int maxInput = 30000; 

  // Sinh test
  for (int i = 1; i <= numTests; i++) {

    n = rand() %(200-50+1)+50;
    char str[n];
    rand_text(n,str);
    char tmp[n]; strcpy(tmp,str);
    replowcase(tmp);	
    generateTest(i, str,tmp); 
  }

  return 0;
}
