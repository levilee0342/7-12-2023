#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>

using namespace std;

void nhap (int a[], int &n)
{
    do
    {
        cin>>n;
    }while(n <= 0 || n > 20);
    for(int i = 0; i < n; i++)
    {
        cin>>a[i];
    }
}

void xuat(int a[], int n)
{
    for(int i = 0; i < n; i++)
    {
        cout<<a[i];
    }
}

void HoanVi(int &a, int &b)
{
    int tam = a;
    a = b;
    b = tam;
}

void DaoMang(int a[], int n)
{
    for(int i = 0, j = n - 1; i < j; i++, j--)
    {
        HoanVi(a[i], a[j]);
    }
} 



void generateTest(int testNumber, int a[], int n) {
  string inputFilename =  to_string(testNumber) + ".in";
  ofstream inputFile(inputFilename);

  inputFile<<n<<endl;
  for(int i = 0; i< n; i++)
  {
  	inputFile << a[i]<<endl;
  }
  
//  int output1 = giatrimax(a,n); int output2 = giatrimin(a,n);


  string outputFilename = to_string(testNumber) + ".out";
  ofstream outputFile(outputFilename);
	DaoMang(a,n);
	outputFile<<n<<endl;
	for(int i = 0; i< n; i++)
  	{
  		outputFile << a[i]<<endl;
  	}
  
  inputFile.close();
  outputFile.close();
}

int main() {
	int n;
	srand(time(NULL)); 
	
  int numTests = 10; 
  int minInput = -30000; 
  int maxInput = 30000; 

  // Sinh test
  for (int i = 1; i <= numTests; i++) {

    n = rand() % 20 + 1;
    int a[n];
    for(int j = 0; j<n; j++)
    {
    	a[j] = rand() % (maxInput - minInput + 1) + minInput;
	}
    	
    generateTest(i, a,n); 
  }

  return 0;
}
