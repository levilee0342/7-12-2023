#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>

using namespace std;


void generateTest(int testNumber, int in, int out) 
{
	string inputFilename = to_string(testNumber) + ".in";
	ofstream inputFile(inputFilename);
	inputFile<< in;
	
	string outputFilename =  to_string(testNumber) + ".out";
	ofstream outputFile(outputFilename);
	
	outputFile << out;
	
	inputFile.close();
	outputFile.close();
}

int totalDigitsOfNumber(int n) {
    int total = 0;
    do {
        total = total + n % 10;
        n = n / 10;
    } while (n > 0);
    return total;
}

int main() {
	int n,a;
	srand(time(NULL)); 
	
	int numTests = 10; 
	int minInput = 0; 
	int maxInput = 30000; 

  // Sinh test
  	for (int i = 1; i <= numTests; i++) 
	{
	    a = rand() % (maxInput - minInput + 1) + minInput;	
	    generateTest(i, a,totalDigitsOfNumber(a)); 
  	}

  return 0;
}
