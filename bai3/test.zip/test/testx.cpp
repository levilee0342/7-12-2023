#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>

using namespace std;
int k;
int KiemTraNamNhuan(int nam)
{
        return (nam % 4 == 0 && nam % 100 != 0) || (nam % 400 == 0);
}
void TimSoNgayTrongThang(int thang, int nam)
{
    switch(thang)
    {
    case 1: case 3: case 5: case 7: case 8: case 10: case 12:
        k=31;
        break;
    case 4: case 6: case 9 : case 11:
        k=30;
        break;
    case 2:
        int Check = KiemTraNamNhuan(nam);
        if(Check == 1)
        {
            k=29;
        }
        else
        {
            k=28;
        }
    }
}



void generateTest(int testNumber, int thang, int nam, int ngay) {
  string inputFilename =  to_string(testNumber) + ".in";
  ofstream inputFile(inputFilename);

  inputFile<<thang<<endl<<nam;

  
	


  string outputFilename = to_string(testNumber) + ".out";
  ofstream outputFile(outputFilename);
	outputFile<<ngay<<endl;

  
  inputFile.close();
  outputFile.close();
}

int main() {
	int n,ngay,thang,nam;
	srand(time(NULL)); 
	
  int numTests = 10; 
  int minInput = -30000; 
  int maxInput = 30000; 

  // Sinh test
  for (int i = 1; i <= numTests; i++) {

    n = rand() % 20 + 1;
    int a[n];
    thang = rand() % (13 - -1 + 1) + -1;
	nam= rand()%(10000- 1900 +1) +1900;
	
    TimSoNgayTrongThang(thang,nam);	
    if (thang < 1 || thang > 12) k=-1;
	if(nam < 1900 || nam > 10000) k=-1;
    generateTest(i, thang,nam,k); 
  }

  return 0;
}
